import os

import pandas
from tqdm import tqdm
from model.utils import (
    get_classical_args, tune_hyper_parameters,
    show_results_classical, get_method, set_seeds, csv_results_classical
)
from model.lib.data import (
    get_dataset
)

METRICS = ["Accuracy", "Avg_Recall", "Avg_Precision", "F1", "LogLoss", "MCC", "AUC", "Time"]
CSV_FILE = "../dt_tabular_csv_allmetrics.csv"
DATA_FOLDER = "../data"
CLF_LIST = ['ConfBagLDA', 'ConfBagNB', 'ConfBagRF', 'ConfBagDT', 'ConfBagLR', 'ConfBagXGB', 'ConfBoostLDA', 'ConfBoostNB', 'ConfBoostRF', 'ConfBoostDT', 'ConfBoostLR', 'ConfBoostXGB', 'LogReg', 'NCM', 'RandomForest',
            'xgboost', 'svm', 'knn', 'NaiveBayes', "dummy",    ]

if __name__ == '__main__':
    # Print Header
    existing_exps = None
    if os.path.exists(CSV_FILE):
        existing_exps = pandas.read_csv(CSV_FILE)
        existing_exps = existing_exps.loc[:, ['dataset', 'clf']]
    else:
        with open(CSV_FILE, 'w') as f:
            f.write('dataset,clf')
            for tag in METRICS:
                f.write("," + tag + "_avg," + tag + "_std")
            f.write("\n")

    for dataset_name in os.listdir(DATA_FOLDER):
        dataset_dir = os.path.join(DATA_FOLDER, dataset_name)
        for alg in CLF_LIST:
            if existing_exps is not None and (((existing_exps['dataset'] == dataset_name) &
                                               (existing_exps['clf'] == alg)).any()):
                print('Skipping classifier %s, already in the results' % alg)
            else:
                print("\n\nExperiment with %s on %s" % (alg, dataset_name))
                results_list, time_list = [], []
                args, default_para, opt_space = get_classical_args(dataset_name, alg)
                train_val_data, test_data, info = get_dataset(args.dataset, args.dataset_path)
                if args.tune:
                    args = tune_hyper_parameters(args, opt_space, train_val_data, info)
                # Check classification
                if info["task_type"] != "regression":
                    ## Training Stage over different random seeds
                    #try:
                    for seed in tqdm(range(args.seed_num)):
                        args.seed = seed  # update seed
                        set_seeds(args.seed)
                        method = get_method(args.model_type)(args, info['task_type'] == 'regression')
                        time_cost = method.fit(train_val_data, info, train=True)
                        vres, metric_name, predict_logits = method.predict(test_data, info, model_name=args.evaluate_option)

                        results_list.append(vres)
                        time_list.append(time_cost)
                    csv_results_classical(args, info, metric_name, results_list, time_list, CSV_FILE, alg, dataset_name, METRICS)
                    #except:
                    #    print("Alg %s failed" % alg)