from model.classical_methods.knn import KnnMethod
from copy import deepcopy
import os.path as ops
import pickle

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

from LAMDA_TALENT.confens.ConfidenceBoosting import ConfidenceBoosting


class ConfBoostLDAMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config = None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=LinearDiscriminantAnalysis(), random_state=self.args.seed)


class ConfBoostDTMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config=None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=DecisionTreeClassifier(random_state=self.args.seed),
                                            random_state=self.args.seed)


class ConfBoostRFMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config=None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=RandomForestClassifier(n_estimators=10, random_state=self.args.seed),
                                            random_state=self.args.seed)


class ConfBoostNBMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config=None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=GaussianNB(),
                                            random_state=self.args.seed)


class ConfBoostLRMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config=None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=LogisticRegression(penalty='l2', max_iter=5000, random_state=self.args.seed),
                                            random_state=self.args.seed)


class ConfBoostXGBMethod(KnnMethod):
    def __init__(self, args, is_regression):
        super().__init__(args, is_regression)

    def construct_model(self, model_config=None):
        if model_config is None:
            model_config = self.args.config['model']
        if self.is_regression:
            self.model = DummyRegressor(strategy='mean')
        else:
            self.model = ConfidenceBoosting(**model_config, clf=XGBClassifier(subsample=0.8,
                                                                              n_jobs=-1, tree_method='hist', n_estimators=100, random_state=self.args.seed),
                                            random_state=self.args.seed)
    